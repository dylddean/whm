$(document).ready(function() {

    /*--------- Toggle Menu ----------*/
    $(".toggle").click(function() {
        $(this).toggleClass("on");
        $(".menu_inner").toggleClass('show');
        $("body").toggleClass('cm_overflow');
        $('.menu_inner > li').toggleClass('open');
    });
});